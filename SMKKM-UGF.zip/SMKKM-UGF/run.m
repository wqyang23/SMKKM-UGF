close all
clear
clc
warning off;

addpath(genpath('ClusteringMeasure'));
addpath(genpath('function'));
addpath(genpath('FormulationKernels'));

ResSavePath = 'Res/';
MaxResSavePath = 'maxRes/';

dataPath='../Datasets/';
datasetName = {'Carcinom_173_11_Kmatrix', 'wisconsin_Kmatrix', 'YALE_Kmatrix',...
'caltech101_nTrain5_48_Kmatrix', 'caltech101_nTrain10_48_Kmatrix', 'caltech101_nTrain15_48_Kmatrix',...
'caltech101_nTrain20_48_Kmatrix', 'caltech101_nTrain25_48_Kmatrix', 'caltech101_nTrain30_48_Kmatrix', 'Handwritten_numerals_Kmatrix'};

for dataIndex = 3:length(datasetName) - (length(datasetName) - 3)
    dataName = [dataPath datasetName{dataIndex} '.mat'];
    load(dataName, 'KH', 'Y');
    KH = knorm(kcenter(KH));
    
    ResBest = zeros(1, 8);
    ResStd = zeros(1, 8);
    
    % Data Preparation
    tic;
    num_cluster = max(Y);
%     [KH, HH] = preprocess(fea, num_cluster);
    time1 = toc;
    
    % parameters setting
    
    r1 = 1 : 1 : 10;
    r2 = 0 : 0.25 : 1;
    
    %     r1 = 2;
    %     r2 = 0.4;
    
    acc = zeros(length(r1), length(r2));
    nmi = zeros(length(r1), length(r2));
    purity = zeros(length(r1), length(r2));
    idx = 1;
    
    for r1Index = 1 : length(r1)
        r1Temp = r1(r1Index);
        for r2Index = 1 : length(r2)
            r2Temp = r2(r2Index);
            tic;
            % Main algorithm
            fprintf('Please wait a few minutes\n');
            disp(['Dataset: ', datasetName{dataIndex}, ...
                ', --r1--: ', num2str(r1Temp), ...
                ', --r2--: ', num2str(r2Temp)]);
            
            [KH_sum, S, weight, F, obj] = demo_cluster(KH, num_cluster, r1Temp, r2Temp);
            
            time2 = toc;
            
            tic;
            [res] = my_nmi_acc(real(F), Y, num_cluster);
            time3 = toc;
            
            Runtime(idx) = time1 + time2 + time3/20;
            disp(['runtime: ', num2str(Runtime(idx))]);
            idx = idx + 1;
            tempResBest(1, :) = res(1, :);
            tempResStd(1, :) = res(2, :);
            
            acc(r1Index, r2Index) = tempResBest(1, 7);
            nmi(r1Index, r2Index) = tempResBest(1, 4);
            purity(r1Index, r2Index) = tempResBest(1, 8);
            
            resFile = [ResSavePath datasetName{dataIndex}, '-ACC=', num2str(tempResBest(1, 7)), ...
                '-r1=', num2str(r1Temp), ...
                '-r2=', num2str(r2Temp), '.mat'];
            save(resFile, 'tempResBest', 'tempResStd');
            
            for tempIndex = 1:8
                if tempResBest(1, tempIndex) > ResBest(1, tempIndex)
                    new_KH = KH_sum;
                    new_S = S;
                    new_mu = weight;
                    new_F = F;
                    new_obj = obj;
                    ResBest(1, tempIndex) = tempResBest(1, tempIndex);
                    ResStd(1, tempIndex) = tempResStd(1, tempIndex);
                end
            end
        end
    end
    aRuntime = mean(Runtime);
    resFile2 = [MaxResSavePath datasetName{dataIndex}, '-ACC=', num2str(ResBest(1, 7)), '.mat'];
    save(resFile2, 'ResBest', 'ResStd');
    resFile2 = [MaxResSavePath datasetName{dataIndex}, '.mat'];
    save(resFile2, 'ResBest', 'ResStd', 'acc', 'nmi', 'purity', 'aRuntime',...
        'new_KH', 'new_S', 'new_mu', 'new_F', 'new_obj', 'Y');
end

