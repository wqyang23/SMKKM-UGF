function [KH_sum, S, mu, F, obj] = demo_cluster(KH, num_cluster, num_filter, eta)
[num_sample, ~, num_kernel] = size(KH);
knn = 15;
%
mu = sqrt(ones(num_kernel, 1) / num_kernel);
KH_sum = zeros(num_sample, num_sample);
for p = 1 : num_kernel
    KH_sum = KH_sum + mu(p) * KH(:, :, p);
end

[S] = initial_graph(mean(mu) * ones(num_sample, num_sample) - KH_sum, knn);
D = diag(sum(S) + eps);
A = D ^(-0.5) * S * D ^(-0.5);
L = (0.5 * eye(num_sample) + 0.5 *  A);
KH_sum = L^num_filter * KH_sum * L^num_filter;
S_pre = S;

max_iter = 30;
iter = 1;
while(iter <= max_iter)
    % update F
    [F, ~] = eigs(KH_sum, num_cluster, 'la');
    
    % update 
    F_ = F ./ repmat(sqrt(sum(F.^2, 2)), 1, num_cluster);
    S = constructW_PKN(F_', knn);
%     if iter > 1
        S = (1 - eta) * S_pre + eta * S;
%     end
    S_pre = S;
    
    D = diag(sum(S) + eps);
    A = D ^(-0.5) * S * D ^(-0.5);
    L = (0.5 * eye(num_sample) + 0.5 *  A);
    
    % update mu
    f = zeros(num_kernel, 1);
    temp = L^num_filter * (F * F') * L^num_filter;
    for p = 1 : num_kernel
        f(p) = trace(KH(:, :, p) * temp) + eps;
    end
    mu = f ./ norm(f);
    
    % update KH_sum
    KH_sum = zeros(num_sample, num_sample);
    for p = 1 : num_kernel
        KH_sum = KH_sum + mu(p) * KH(:, :, p);
    end
       
    %
    KH_sum = L^num_filter * KH_sum * L^num_filter;
    
    % update obj
    obj(iter) = trace(F' * KH_sum * F);
    
    if iter > 2 && abs((obj(iter) - obj(iter - 1)) / obj(iter)) < 1e-6
        break;
    end
    iter = iter + 1;
    
end
F = F ./ repmat(sqrt(sum(F.^2, 2)), 1, num_cluster);

end